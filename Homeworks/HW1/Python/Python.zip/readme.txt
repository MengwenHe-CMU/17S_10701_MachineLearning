First time to use Python~
Sry for any inconvenience.

Codes are in the "hw1_A.py" and "hw1_B.py", which contain the main function can be directly run by python shell.
If you want to test the code, please copy the data folder "test" and "train" in the same folder with the codes.
Thx!